﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lenguajes_3_Actividad_1
{
    public partial class Form1 : Form
    {
        // Cadena de Conexión
        string cadena = "Data Source=LAPTOP-OPGPGCFR\\SQLEXPRESS;Initial Catalog=Kamil;Integrated Security=True";
        SqlConnection Conectarbd = new SqlConnection();

        public Form1()
        {
            InitializeComponent();
            Conectarbd.ConnectionString = cadena;
            abrir();
            cerrar();
        }

        // Método para abrir la conexión
        public void abrir()
        {
            try
            {
                Conectarbd.Open();
                MessageBox.Show("Conexión abierta");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al abrir BD: " + ex.Message);
            }
        }

        // Método para cerrar la conexión
        public void cerrar()
        {
            Conectarbd.Close();
        }
    }
}
